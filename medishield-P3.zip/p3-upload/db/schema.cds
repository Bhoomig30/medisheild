
namespace medishield;

entity Risks {
    key risk_id          : String(40);
        event            : String(500);
        region           : String(100);
        affected_supplier: String(120);
        tier             : Integer;
        confidence       : String(20);
        source           : String(500);
        reason           : LargeString;
        evidence_type    : String(30);
        matched_on       : String(100);
}

entity Stocks {
    key material        : String(120);
        unit             : String(20);
        stock_units      : Decimal(15,2);
        daily_usage      : Decimal(15,2);
        lead_time_days   : Integer;
}

entity SupplierDeclarations {
    key declaration_id  : String(40);
        risk_id          : String(40);
        share_percent    : Decimal(5,2);
        backup_available : Boolean;
}

entity Impacts {
    key risk_id          : String(40);
        delay_days       : Integer;
        days_of_stock    : Integer;
        production_at_risk: String(500);
}

entity Options {
    key option_id        : String(40);
        risk_id          : String(40);
        type             : String(80);
        cost_estimate    : Decimal(15,2);
        delay_saved_days : Integer;
        rank             : Integer;
}

entity Messages {
    key message_id       : String(40);
        risk_id          : String(40);
        to_supplier      : String(100);
        body             : LargeString;
        language         : String(5);
        body_translated  : LargeString;
        status           : String(30);
        reply_text       : LargeString;
        reply_timestamp  : Timestamp;
}

entity Simulations {
    key simulation_id    : String(40);
        risk_id          : String(40);
        delay_days       : Integer;
        stock_units      : Decimal(15,2);
        share_percent    : Decimal(5,2);
        calculated_shortfall : Decimal(15,2);
        created_at       : Timestamp;
}
