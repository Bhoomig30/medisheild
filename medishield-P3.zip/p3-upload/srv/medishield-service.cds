
using { medishield as db } from '../db/schema';

service MediShieldService {

    entity Risks as projection on db.Risks;
    entity Stocks as projection on db.Stocks;
    entity SupplierDeclarations as projection on db.SupplierDeclarations;
    entity Impacts as projection on db.Impacts;
    entity Options as projection on db.Options;
    entity Messages as projection on db.Messages;
    entity Simulations as projection on db.Simulations;

    // Calculate supply disruption impact
    action calcImpact(
        riskId: String(40)
    ) returns Impacts;

    // Rank recovery options
    action rankOptions(
        riskId: String(40)
    ) returns many Options;

    // Generate supplier message without API key
    action draftMessage(
        riskId: String(40),
        tier1SupplierId: String(100),
        tier1SupplierName: String(120)
    ) returns Messages;

    // Run what-if simulation
    action simulateImpact(
        riskId: String(40),
        delayDays: Integer,
        stockUnits: Decimal(15,2),
        sharePercent: Decimal(5,2)
    ) returns Simulations;

}
