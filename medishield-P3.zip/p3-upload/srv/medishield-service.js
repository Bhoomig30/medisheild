
import cds from '@sap/cds';
import rules from './lib/rules.cjs';
import messageModule from './lib/draftMessage.cjs';
import { randomUUID } from 'node:crypto';

const { calcImpactCore, rankOptionsCore } = rules;
const { draftMessage: createDraftMessage } = messageModule;

const { SELECT, UPSERT, INSERT, DELETE } = cds.ql;

export default cds.service.impl(async function () {

    const {
        Risks,
        Stocks,
        SupplierDeclarations,
        Impacts,
        Options,
        Messages,
        Simulations
    } = this.entities;

    // ==========================================
    // 1. CALCULATE IMPACT
    // ==========================================

    this.on('calcImpact', async (req) => {

        const { riskId } = req.data;

        if (!riskId) {
            return req.error(400, 'Risk ID is required');
        }

        const risk = await SELECT.one.from(Risks)
            .where({ risk_id: riskId });

        if (!risk) {
            return req.error(404, 'Risk not found');
        }

        const stock = await SELECT.one.from(Stocks);

        if (!stock) {
            return req.error(404, 'Stock details not found');
        }

        if (!Number(stock.daily_usage) ||
            Number(stock.daily_usage) <= 0) {
            return req.error(400, 'Daily usage must be greater than zero');
        }

        const declaration = await SELECT.one.from(SupplierDeclarations)
            .where({ risk_id: riskId });

        const { impact } = calcImpactCore({
            risk,
            stock,
            declaration
        });

        await UPSERT.into(Impacts).entries(impact);

        return impact;
    });

    // ==========================================
    // 2. RANK RECOVERY OPTIONS
    // ==========================================

    this.on('rankOptions', async (req) => {

        const { riskId } = req.data;

        if (!riskId) {
            return req.error(400, 'Risk ID is required');
        }

        const risk = await SELECT.one.from(Risks)
            .where({ risk_id: riskId });

        if (!risk) {
            return req.error(404, 'Risk not found');
        }

        const stock = await SELECT.one.from(Stocks);

        if (!stock) {
            return req.error(404, 'Stock details not found');
        }

        if (!Number(stock.daily_usage) ||
            Number(stock.daily_usage) <= 0) {
            return req.error(400, 'Daily usage must be greater than zero');
        }

        const declaration = await SELECT.one.from(SupplierDeclarations)
            .where({ risk_id: riskId });

        const impact = await SELECT.one.from(Impacts)
            .where({ risk_id: riskId });

        if (!impact) {
            return req.error(
                400,
                'Calculate impact before ranking options'
            );
        }

        const share =
            (Number(risk.tier) === 1 ||
             !declaration ||
             declaration.share_percent == null)
                ? 100
                : Number(declaration.share_percent);

        const gap = Math.max(
            0,
            Number(impact.delay_days) -
            Number(impact.days_of_stock)
        );

        const shortfallKg = Math.round(
            gap * Number(stock.daily_usage) * share / 100
        );

        const calc = {
            gap,
            shortfallKg,
            share
        };

        const options = rankOptionsCore({
            risk,
            impact,
            calc,
            stock,
            declaration,
            hasAlternate: Boolean(
                declaration &&
                declaration.backup_available === true
            )
        });

        const records = options.map(option => {
            const { option_rank, ...rest } = option;

            return {
                ...rest,
                rank: option_rank
            };
        });

        await DELETE.from(Options)
            .where({ risk_id: riskId });

        if (records.length > 0) {
            await INSERT.into(Options).entries(records);
        }

        return records;
    });

    // ==========================================
    // 3. DRAFT SUPPLIER MESSAGE
    // ==========================================

    this.on('draftMessage', async (req) => {

        const {
            riskId,
            tier1SupplierId,
            tier1SupplierName
        } = req.data;

        if (!riskId) {
            return req.error(400, 'Risk ID is required');
        }

        const risk = await SELECT.one.from(Risks)
            .where({ risk_id: riskId });

        if (!risk) {
            return req.error(404, 'Risk not found');
        }

        const impact = await SELECT.one.from(Impacts)
            .where({ risk_id: riskId });

        if (!impact) {
            return req.error(
                400,
                'Calculate impact before drafting a message'
            );
        }

        let supplier;

        if (Number(risk.tier) === 1) {

            supplier = {
                supplier_id:
                    tier1SupplierId || risk.affected_supplier,
                name:
                    tier1SupplierName || risk.affected_supplier
            };

        } else {

            if (!tier1SupplierId || !tier1SupplierName) {
                return req.error(
                    400,
                    'Tier-1 supplier ID and name are required for upstream disruptions'
                );
            }

            supplier = {
                supplier_id: tier1SupplierId,
                name: tier1SupplierName
            };
        }

        const generatedMessage = createDraftMessage({
            risk,
            impact,
            tier1: supplier,
            message_id: `M-${randomUUID()}`
        });

        await INSERT.into(Messages).entries(generatedMessage);

        return generatedMessage;
    });

    // ==========================================
    // 4. WHAT-IF SIMULATION
    // ==========================================

    this.on('simulateImpact', async (req) => {

        const {
            riskId,
            delayDays,
            stockUnits,
            sharePercent
        } = req.data;

        // Validate inputs
        if (!riskId) {
            return req.error(400, 'Risk ID is required');
        }

        if (!Number.isInteger(Number(delayDays)) ||
            Number(delayDays) < 0) {
            return req.error(
                400,
                'Delay days must be a non-negative whole number'
            );
        }

        if (!Number.isFinite(Number(stockUnits)) ||
            Number(stockUnits) < 0) {
            return req.error(
                400,
                'Stock units must be a non-negative number'
            );
        }

        if (!Number.isFinite(Number(sharePercent)) ||
            Number(sharePercent) < 0 ||
            Number(sharePercent) > 100) {
            return req.error(
                400,
                'Share percentage must be between 0 and 100'
            );
        }

        // Find the existing risk
        const risk = await SELECT.one.from(Risks)
            .where({ risk_id: riskId });

        if (!risk) {
            return req.error(404, 'Risk not found');
        }

        // Get existing stock details
        const existingStock = await SELECT.one.from(Stocks);

        if (!existingStock) {
            return req.error(404, 'Stock details not found');
        }

        if (!Number(existingStock.daily_usage) ||
            Number(existingStock.daily_usage) <= 0) {
            return req.error(
                400,
                'Daily usage must be greater than zero'
            );
        }

        // Get supplier declaration
        const existingDeclaration =
            await SELECT.one.from(SupplierDeclarations)
                .where({ risk_id: riskId });

        // Create temporary simulated values.
        // These do NOT update the original database records.
        const simulatedStock = {
            ...existingStock,
            stock_units: Number(stockUnits)
        };

        const simulatedDeclaration = {
            ...(existingDeclaration || {}),
            risk_id: riskId,
            share_percent: Number(sharePercent)
        };

        // Calculate simulated impact
        const { impact, calc } = calcImpactCore({
            risk,
            stock: simulatedStock,
            declaration: simulatedDeclaration,
            delayDays: Number(delayDays)
        });

        // Calculate recovery options for this scenario
        const simulatedOptions = rankOptionsCore({
            risk,
            impact,
            calc,
            stock: simulatedStock,
            declaration: simulatedDeclaration,
            hasAlternate: Boolean(
                simulatedDeclaration.backup_available === true
            )
        });

        // Save the simulation result
        const simulation = {
            simulation_id: `SIM-${randomUUID()}`,
            risk_id: riskId,
            delay_days: Number(delayDays),
            stock_units: Number(stockUnits),
            share_percent: Number(calc.share),
            calculated_shortfall: Number(calc.shortfallKg),
            created_at: new Date()
        };

        await INSERT.into(Simulations).entries(simulation);

        return simulation;
    });

});
