const { draftMessage } = require('../srv/lib/draftMessage.cjs');
(async () => {
  console.log(await draftMessage({
    risk: { risk_id: 'RA1', tier: 2, region: 'Zhejiang', event: 'Port closure in Zhejiang' },
    impact: { days_of_stock: 9, delay_days: 14 },
    tier1: { supplier_id: 'S1', name: 'Sharma Traders' } }));
  console.log(await draftMessage({
    risk: { risk_id: 'RB1', tier: 1, region: 'Hyderabad', event: 'Deccan Pharma Chem says shipment delayed 10 days' },
    impact: { days_of_stock: 9, delay_days: 10 },
    tier1: { supplier_id: 'S2', name: 'Deccan Pharma Chem' } }));
})();
