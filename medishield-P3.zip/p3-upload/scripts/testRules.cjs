const { calcImpactCore, rankOptionsCore } = require('../srv/lib/rules.cjs');
const stock = { material: 'Paracetamol API', unit: 'kg', stock_units: 4500, daily_usage: 500, lead_time_days: 14 };
const cases = [
  { risk: { risk_id: 'RB1', tier: 1, event: 'Deccan Pharma Chem says shipment delayed 10 days' }, declaration: null },
  { risk: { risk_id: 'RA1', tier: 2, event: 'Port closure in Zhejiang' }, declaration: { share_percent: 60, backup_available: false } }
];
for (const c of cases) {
  const { impact, calc } = calcImpactCore({ ...c, stock });
  console.log(impact, rankOptionsCore({ ...c, impact, calc, stock, hasAlternate: true }));
}